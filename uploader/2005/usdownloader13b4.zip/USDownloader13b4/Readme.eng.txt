Universal Share Downloader v1.3 Beta 4

Universal Share Downloader need for automatic download from 
file sharing sites.

Sample plg file is in MyTempDir.src.zip (language Delphi)

In current time programn have this plugins:
- RapidShare.plg (for download from RapidShare.de)
- MyTempDir.plg  (for download from MyTempDir.com)
- MegaUpload.plg (for download from www.megaupload.com)
- WebFile.plg    (for download from www.webfile.ru)
- SendMeFile.plg (for download from www.sendmefile.com)
- YouSendIt.plg  (for download from www.yousendit.com)
- Upload2.plg    (for download from www.upload2.net)

If you want english interface - rename usdownloader~.lng to usdownloader.lng 
and restart program 

Emails for connect:
dimonius@dimonius.ru
dimonius@mail333.com

Program is FREE and distributed "AS IS"
Autor not garanted normal work of this program or
not damage data with use this program

New versions, plg and lng files you may download free from
home site http://www.dimonius.ru
