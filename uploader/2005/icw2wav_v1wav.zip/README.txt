Release: Icw2Wav version 1.0  (0ct 2005)
Author: Peter Stevenson
Contact: peterstevenson@btinternet.com
---------------------------------------

#Summary#
This zip file contains a program to convert ICW, a file format which is produced
by the Icom R20 radio scanner, to WAV file for easy playback and editting.
Released for the Icom R20 Yahoo group http://groups.yahoo.com/group/IC-R20/

Thanks to Tony, Brett, MikeP, Scanman, SteveC and Walter and everyone in the R20
yahoo group for their help and support in producing this application.
	
----------------------------------------

#Pre-Requisites#

This application requires the following:
	
1) Microsoft .NET Framework 1.1 (23698 KB).  This may be already installed on your PC.
Try the exe first, it may save you a download.  If not it is available here:
http://www.microsoft.com/downloads/details.aspx?FamilyID=262d25e3-f589-4842-8157-034d1e7cf3a3&DisplayLang=en

2) OkiAudio.dll, OkiAdpcmEnc.dll, OkiAdpcmDec.dll.  For licensing reasons these 
libraries are not included in the release.  The dlls can be found in the following 
zip file:
http://www.p4c.philips.com/files/c/ct5358_afusa0p2/ct5358_afusa0p2_ics_eng.zip
(17608 KB)
Copy the files within the directory UK/Data to the same directory as the 
'icw2wav.exe'.
----------------------------------------

#Installation#

Extract the exe file to an appropriate directory e.g. "C:\Program Files\Icw2Wav" and
copy the above dll files to this same directory.

----------------------------------------

#Use#

Self explanatory I hope :)  

GUI: Run the icw2wav.exe file, click the Convert ICW.." button and select icw file to
convert.  A wav file version of the icw file will be written to the same directory as
the icw file.

CONSOLE: The application can take one parameter defining the full path to the icw file
to convert.  

** Optionally users can set windows to open icw files with the icw2wav.exe
application, allowing them to double click icw files and immediately convert them to
wav.  This can be done by:
	- Double clicking an icw file
	- Choose "Select application from a list"
	- Browse to the location of your installed icw2wav.exe executable

Enjoy!

----------------------------------------

#Bugs or Improvements#

Please let me know of any bugs or improvements you'd like to see:
peterstevenson@btinternet.com

----------------------------------------

#Source Code#

I am happy to release the source code to anyone for non-commerical purposes.
Contact the author.

----------------------------------------

#DISCLAIMER#

       DISCLAIMER OF WARRANTY

THIS SOFTWARE AND MANUAL ARE PROVIDED "AS IS" AND WITHOUT
WARRANTIES AS TO PERFORMANCE OF MERCHANTABILITY OR ANY
OTHER WARRANTIES WHETHER EXPRESSED OR IMPLIED. BECAUSE
OF THE VARIOUS HARDWARE AND SOFTWARE ENVIRONMENTS INTO
WHICH THIS PROGRAM MAY BE PUT, NO WARRANTY OF FITNESS FOR
A PARTICULAR PURPOSE IS OFFERED. GOOD DATA PROCESSING
PROCEDURE DICTATES THAT ANY PROGRAM BE THOROUGHLY TESTED
WITH NON-CRITICAL DATA BEFORE RELYING ON IT. THE USER
MUST ASSUME THE ENTIRE RISK OF USING THE PROGRAM. THE
DEVELOPER DOES NOT RETAIN ANY LIABILITY ON ANY DAMAGE
CAUSED THROUGH THE USE OF THIS PRODUCT.

LICENSE TO USE:

You are permitted to freely distribute this program and its 
associated files provided that (1) You do not charge a fee for 
its distribution, (2) you do not include it as a part of a 
commercial offering, and (3) you do distribute all 
accompanying files together.

* All products mentioned are trademarks or registered trademarks 
of their respective owners.

------------------------------------------------


Comment by tetrascanner (www.tetrascanner.com)
In case of problems check out:   http://groups.yahoo.com/group/IC-R20
maybe you find the answer to your question there


