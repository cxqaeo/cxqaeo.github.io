// ft.cpp : Read and write EEPROM configuration data from FT817 and FT897
//
// Usage: ft <byte1> <byte2>, where byte1 and byte2 are the two hex values to put into address 4 and address 5 in the EEPROM
//        ft -r, reads the current EEPROM values only, does not write.
// 
// License: Freeware. If you break it, you own both halves. If you use it, please acknowledge the original author.
//                    If you screw your radio, your problem.
//                    There are no restrictions on distribution or copying, provided you mention the original author.
//					  If you modify the code, please send a copy back to me at vk2it@tpg.com.au
//					  I'd love to hear your comments and stories via a QSL card !
//
// Revision History
//
// Ver	Date		Who				Comments.
// 0.1	03/08/2003	Peter May		Original version
// 0.2	06/09/2003	Peter May		Updates for COM port selection and change my Call to VK2IT from VK2JCG!
//

#include "stdafx.h"
#include <io.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>

#define READ_INFO		0xA7
#define READ_EEPROM		0xBB
#define WRITE_EEPROM	0xBC

// '897 Jumper Values, inverted sense: 0 = Jumper, 1 = No Jumper, other bits unused/unknown.

// Byte 1:

#define FT897_J1001     0x40
#define FT897_J1002     0x20 
#define FT897_J1003     0x10 
#define FT897_J1007     0x04 
#define FT897_J1008     0x02 
#define FT897_J1009     0x01 

// Byte 2:

#define FT897_J1004     0x04 
#define FT897_J1005     0x02 
#define FT897_J1006     0x01 


void usage()
{
	printf( "Usage: ft [-#]               Reads the current EEPROM values only, does not\n" );
	printf( "                             write anything to the EEPROM\n\n" );
	printf( "       ft [-#] <B1> <B2>     Byte1 and byte2 are the two hex values\n" );
	printf( "                             to put into address 4 and address 5 in the EEPROM\n\n" );
	printf( "                             Optional: -#, use COM port COM#\n\n" );
	printf( "Example: ft 70 06            Writes the values 70 06 to the EEPROM via COM1:\n" );
	printf( "         ft -2               Reads the current values using COM2:\n" );
	printf( "         ft -2 F8 BF         Writes F8 BF using COM2:\n\n" );
	
	exit( 1 );
}

// Printcat simply prints the response from the radio in Hex.

void printcat( char *msg, unsigned long count, unsigned char *bfr )
{
	printf( "%s: ", msg );

	while( count )
	{
		printf( "%02X ", *bfr );
		count--;
		bfr++;
	}
	printf( "\n" );
}


// fromhex: Converts a HEX string to an unsigned char - only works for max of 2 character strings.

unsigned char fromhex( char *s )
{
	unsigned char rv = 0;

	if( *s >= '0' && *s <= '9' )
		rv = *s - '0';

	*s = toupper( *s );
	if( *s >= 'A' && *s <= 'F' )
		rv = *s - 'A' + 10;

	*s++;

	if( ! *s )
		return( rv );

	rv = rv * 16;

	if( *s >= '0' && *s <= '9' )
		rv += *s - '0';

	*s = toupper( *s );
	if( *s >= 'A' && *s <= 'F' )
		rv += *s - 'A' + 10;

	return( rv );
}


		
int main(int argc, char *argv[] )
{
	DCB				dcb;
	HANDLE			hCom;
	BOOL			fSuccess;
	COMMTIMEOUTS	cto;

	int				readflag;
	int				comport = 1;
	char			cpstr[8];
	char			*argp;
	unsigned long	count;

	unsigned char	sbuf[6];
	unsigned char	rbuf[32];
	char			wbuf[32];

	printf( "%s version 0.2 by Peter May, VK2IT, vk2it@tpg.com.au\n\n", argv[0] );
	printf( "This program uses undocumented CAT commands to read or update the EEPROM\n" );
	printf( "in the Yaesu FT817, FT857, and FT897 Radios. The soft jumper settings are stored\n" );
	printf( "in location 4 and 5 of the EEPROM. Power the radio off and on to activate\n" );
	printf( "the new settings. If you do a reset of the radio, you will have to run\n" );
	printf( "this program again to rewrite the values\n\n" );
	printf( "The program assumes that the radio CAT rate is set to 38400 baud\n\n" );
	printf ( "*** USE AT YOUR OWN RISK ***\n\n" );

	// check arguments

	if( ( argc > 1 ) && ( *argv[1] == '-' ) )		// Is the COM: port specified ?
	{
		argp = argv[1];
		++argp;				// skip over the -
		comport = atoi( argp );

		if( ( comport < 1 ) || ( comport > 9 ) )
			usage();

		argc--;				// we are done with this argument 
		argv++;				// skip to next

	}
	else
		comport = 1;

	sprintf( cpstr, "COM%d:", comport );
	
	if( argc == 1 )			// No arguments, read the EEPROM only.
		readflag = 1;
	else
	{
		readflag = 0;

		if( argc != 3 )			// must supply the two hex values
			usage();
	}

	// Setup the com port. This is a bit messy & from the Win32 API sample code.

	hCom = CreateFile( cpstr, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL );

	if (hCom == INVALID_HANDLE_VALUE)
	{
		printf ("CreateFile failed opening %s with error %d.\n", cpstr, GetLastError());
		return (1);
	}

	fSuccess = GetCommState(hCom, &dcb);

	if (!fSuccess)
	{
		printf ("GetCommState failed with error %d.\n", GetLastError());
		return (1);
    }

	// Fill in the DCB: baud=38400,8,N,2

	dcb.BaudRate = CBR_38400;					// set the baud rate
	dcb.fBinary = TRUE;
	dcb.ByteSize = 8;							// data size, xmit, and rcv
	dcb.Parity = NOPARITY;						// no parity bit
	dcb.StopBits = TWOSTOPBITS;					// two stop bits
	dcb.fOutxCtsFlow = FALSE;					// no CTS output flow control
	dcb.fOutxDsrFlow = FALSE;					// no DSR monitoring for output
	dcb.fDtrControl = DTR_CONTROL_DISABLE;		// do not raise DTR, most interfaces TX the rig if this happens!
	dcb.fDsrSensitivity = FALSE;				// ignore DSR on input of data
	dcb.fOutX = FALSE;							// no XON/XOFF!
	dcb.fInX = FALSE;
	dcb.fNull = FALSE;							// do not discard NULLS
	dcb.fRtsControl = RTS_CONTROL_DISABLE;		// do not raise RTS.

	fSuccess = SetCommState(hCom, &dcb);

	if (!fSuccess)
	{
		printf ("SetCommState failed with error %d.\n", GetLastError());
		return (1);
	}

	cto.ReadIntervalTimeout = 100;				// max of 100ms between characters
	cto.ReadTotalTimeoutConstant = 0;
	cto.ReadTotalTimeoutMultiplier = 0;
	cto.WriteTotalTimeoutConstant = 0;
	cto.WriteTotalTimeoutMultiplier = 0;
	

	fSuccess = SetCommTimeouts( hCom, &cto );

	if ( !fSuccess )
	{
		printf( "SetCommTimeouts failed with error %d.\n", GetLastError());
		return (1);
	}

	printf ("Serial port %s successfully reconfigured.\n\n", cpstr );

	sbuf[0] = 0;
	sbuf[1] = 4;			// returns address data for location 4 and 5
	sbuf[2] = 0;			// my FT897: 37, my FT-817: CE
	sbuf[3] = 0;			// my FT897: 06, my FT-817: BF
	sbuf[4] = READ_EEPROM;

	// Looks like some working unlock values are: 70 06 for FT897 and F8 BF for FT817.

	if( WriteFile( hCom, sbuf, 5, &count, NULL ) == 0 )
	{
		printf ("WriteFile failed with error %d.\n", GetLastError());
		return (1);
	}

	if( count != 5 )
	{
		printf( "Write of CAT command failed, rc = %d\n", count );
		return 0;
	}

	if( ReadFile( hCom, rbuf, 4, &count, NULL ) == 0 )
	{
		printf ("ReadFile failed with error %d.\n", GetLastError());
		return (1);
	}

	printcat( "Software jumpers are set to ", count, rbuf );
	
	if( readflag )			// if we only want to read the EEPROM data, leave now.
		return 0;
	
	sbuf[2] = fromhex( argv[1] );
	sbuf[3] = fromhex( argv[2] );

	printf( "\nAbout to write the values %02x %02x to the EEPROM\n", fromhex( argv[1] ), fromhex( argv[2] ) );
	printf( "Are you SURE you want to do this ?\nPlease answer YES to continue > " );

	fgets( wbuf, 31, stdin );

	if( strncmp( wbuf, "YES", 3 ) != 0 )
	{
		printf( "Aborted: you must enter YES in uppercase to continue and write to the EEPROM\n\n" );
		return 0 ;
	}

	printf( "\nSending CAT command: 00 04 %02x %02x BC to the Radio\n", sbuf[2], sbuf[3] );

	sbuf[0] = 0;
	sbuf[1] = 4;
	sbuf[4] = 0xBC;

	if( WriteFile( hCom, sbuf, 5, &count, NULL ) == 0 )
	{
		printf ("WriteFile failed with error %d.\n", GetLastError());
		return (1);
	}

	if( count != 5 )
	{
		printf( "Write to the radio failed! RC = %d\n", count );
		return 0;
	}

	if( ReadFile( hCom, rbuf, 4, &count, NULL ) == 0 )
	{
		printf ("ReadFile failed with error %d.\n", GetLastError());
		return (1);
	}

	printcat( "Radio response to write command is ", count, rbuf );

	if( rbuf[0] != 0 )
		printf( "Error: Radio did not accept command, should have returned 00\n\n" );
	else
		printf( "Radio accepted write EEPROM command\n\n" );

	// Read the EEPROM values again to verify

	printf( "Reading EEPROM values again:\n" );

	sbuf[0] = 0;
	sbuf[1] = 4;			// returns address data for location 4 and 5
	sbuf[2] = 0;			// my FT897: 37, my FT-817: CE
	sbuf[3] = 0;			// my FT897: 06, my FT-817: BF
	sbuf[4] = READ_EEPROM;

	if( WriteFile( hCom, sbuf, 5, &count, NULL ) == 0 )
	{
		printf ("WriteFile failed with error %d.\n", GetLastError());
		return (1);
	}

	if( count != 5 )
	{
		printf( "Write of CAT command failed, rc = %d\n", count );
		return 0;
	}

	if( ReadFile( hCom, rbuf, 4, &count, NULL ) == 0 )
	{
		printf ("ReadFile failed with error %d.\n", GetLastError());
		return (1);
	}

	printcat( "Read current data from EEPROM gives ", count, rbuf );
	
	printf( "\nEEPROM values updated, power off/on radio to activate\n\n" );

	CloseHandle( hCom );						// finished with config of port, now we use basic I/O
	return 0;
}

