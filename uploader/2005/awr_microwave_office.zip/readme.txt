
Note that this KG works for Microwave Office 2004 

